# assignment1-django-models-sumeyyecildan
#assignment1-django-models-sumeyyecildan
